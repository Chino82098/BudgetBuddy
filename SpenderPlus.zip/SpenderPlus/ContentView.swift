import SwiftUI
import SwiftData

// Shared layout constants
fileprivate let cardEdgeInset: CGFloat = 20
fileprivate let flyoutBottomOffset: CGFloat = 100

struct ContentView: View {
    @Environment(\.modelContext) private var context

    // Theme toggle (read from the same key BudgetsSheet writes)
    @AppStorage("useDarkMode") private var useDarkMode: Bool = false

    // Queries
    @Query(sort: \Transaction.date, order: .reverse) private var txns: [Transaction]
    @Query private var budgets: [Budget]
    @Query private var categoriesRaw: [Category]

    // Cached categories (sorted)
    @State private var categoriesSorted: [Category] = []

    // UI state
    @State private var showingAdd = false
    @State private var showingBudget = false
    @State private var editingTxn: Transaction?
    @State private var month: Date = Date().startOfMonth()
    @State private var expenseTotal: Double = 0

    // Filters
    @State private var selectedCategory: Category?
    @State private var multiSheetPresented = false
    @State private var multiSelectedNames: Set<String> = []

    // Cached filtered list + total
    @State private var visibleTxns: [Transaction] = []
    @State private var netTotal: Double = 0

    // FAB quick pick overlay
    @State private var showCategoryPicker = false
    @State private var addPresetCategory: Category? = nil

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                HeaderArea(
                    month: $month,
                    spent: expenseTotal,
                    budget: overallBudgetAmount(for: month)
                )

                CategoryFilterChips(
                    categories: categoriesSorted,
                    selected: $selectedCategory,
                    multiPresented: $multiSheetPresented,
                    multiSelectedNames: $multiSelectedNames,
                    onSingleChipTap: handleSingleChipTap
                )
                .padding(.horizontal)

                TransactionListSection(
                    txns: visibleTxns,
                    onEdit: { editingTxn = $0 },
                    onDuplicate: duplicate(_:),
                    onDelete: deleteTransaction(_:)
                )
            }
            .navigationTitle("Budget Buddy")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showingBudget = true } label: { Image(systemName: "chart.pie") }
                }
            }
            .overlay(alignment: .bottomLeading) {
                TotalPillOverlay(title: pillTitle, amount: netTotal)
            }
            .overlay(alignment: .bottomTrailing) {
                FabOverlay { showCategoryPicker = true }
            }
            .overlay(alignment: .bottomTrailing) {
                QuickPickFlyoutOverlay(
                    isPresented: showCategoryPicker,
                    categories: categoriesSorted,
                    onDismiss: { showCategoryPicker = false },
                    onPick: { picked in
                        addPresetCategory = picked
                        showCategoryPicker = false
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { showingAdd = true }
                    }
                )
            }
            // Sheets
            .sheet(isPresented: $showingAdd) {
                AddTransactionSheet(selectedMonth: month, preselectedCategory: addPresetCategory)
            }
            .sheet(isPresented: $showingBudget) {
                BudgetsSheet(selectedMonth: month)
            }
            .sheet(item: $editingTxn) { txn in
                EditTransactionSheet(txn: txn)
            }
            .sheet(isPresented: $multiSheetPresented) {
                MultiCategoryPickerSheet(
                    allCategories: categoriesSorted,
                    selectedNames: $multiSelectedNames,
                    onDone: { multiSheetPresented = false },
                    onClear: { multiSelectedNames.removeAll() }
                )
                .presentationDetents([.medium, .large])
            }
            // Seed + first compute
            .task {
                seedDefaultsIfNeeded()
                ensureDefaultCategoriesLocal()   // first-time seed
                syncCategoryColorsWithStyle()    // keep model in sync with CategoryStyle
                sortAndCacheCategories()
                recomputeVisible()
            }
            // Recompute only when inputs change
            .onChange(of: categoriesRaw) { sortAndCacheCategories() }
            .onChange(of: txns) { recomputeVisible() }
            .onChange(of: month) { recomputeVisible() }
            .onChange(of: selectedCategory) { recomputeVisible() }
            .onChange(of: multiSelectedNames) { recomputeVisible() }
        }
        // Apply Dark/Light override from Settings
        .preferredColorScheme(useDarkMode ? .dark : .light)
    }

    // MARK: - Derived labels

    private var pillTitle: String {
        if !multiSelectedNames.isEmpty { return "Total — \(multiSelectedNames.count) Selected" }
        if let cat = selectedCategory { return "Total — \(cat.name)" }
        return "Total — All"
    }

    // MARK: - Cache helpers

    private func sortAndCacheCategories() {
        categoriesSorted = categoriesRaw.sorted { a, b in
            if a.sortIndex != b.sortIndex { return a.sortIndex < b.sortIndex }
            return a.name < b.name
        }
    }

    private func recomputeVisible() {
        let start = month.startOfMonth()
        let end = Calendar.current.date(byAdding: .month, value: 1, to: start) ?? start

        var list = txns.filter { $0.date >= start && $0.date < end }

        if !multiSelectedNames.isEmpty {
            list = list.filter { t in
                guard let name = t.category?.name else { return false }
                return multiSelectedNames.contains(name)
            }
        } else if let cat = selectedCategory {
            list = list.filter { $0.category?.persistentModelID == cat.persistentModelID }
        }

        visibleTxns = list
        netTotal = list.reduce(0) { $0 + $1.amount }
        expenseTotal = list.filter { $0.amount < 0 }.reduce(0) { $0 + (-$1.amount) }
    }

    private func overallBudgetAmount(for month: Date) -> Double {
        let start = month.startOfMonth()
        return budgets.first(where: { $0.monthStart == start && $0.category == nil })?.amount ?? 0
    }

    // MARK: - Seeding + Color migration

    private func ensureDefaultCategoriesLocal() {
        guard categoriesRaw.isEmpty else { return }

        // Seed from CategoryStyle so app-wide colors/icons are consistent
        let orderedNames = ["Dining", "Transport", "Bills", "Income", "Entertainment", "Shopping"]
        for (idx, name) in orderedNames.enumerated() {
            let hex = CategoryStyle.desiredColors[name] ?? "#6B7280"
            let icon = CategoryStyle.icon(for: name)
            context.insert(Category(name: name, icon: icon, colorHex: hex, sortIndex: idx))
        }
        try? context.save()
    }

    private func syncCategoryColorsWithStyle() {
        var needsSave = false
        for cat in categoriesRaw {
            if let wantedHex = CategoryStyle.desiredColors[cat.name], cat.colorHex != wantedHex {
                cat.colorHex = wantedHex
                needsSave = true
            }
            // Also keep icons in sync if you changed them
            let wantedIcon = CategoryStyle.icon(for: cat.name)
            if cat.icon != wantedIcon {
                cat.icon = wantedIcon
                needsSave = true
            }
        }
        if needsSave { try? context.save() }
    }

    private func seedDefaultsIfNeeded() {
        let monthStart = Date().startOfMonth()
        if !budgets.contains(where: { $0.monthStart == monthStart && $0.category == nil }) {
            context.insert(Budget(monthStart: monthStart, amount: 2000))
            try? context.save()
        }
    }

    // MARK: - Actions

    private func handleSingleChipTap(_ newSelection: Category?) {
        multiSelectedNames.removeAll()
        selectedCategory = newSelection
    }

    private func duplicate(_ t: Transaction) {
        let copy = Transaction(
            amount: t.amount, date: t.date, note: t.note, category: t.category,
            isRecurring: t.isRecurring, recurFrequency: t.recurFrequency,
            recurInterval: t.recurInterval, recurEndDate: t.recurEndDate, recurGroupID: t.recurGroupID
        )
        context.insert(copy)
        try? context.save()
    }

    private func deleteTransaction(_ t: Transaction) {
        context.delete(t)
        try? context.save()
    }
}

//
// MARK: - Small subviews (kept lightweight)
//

private struct TransactionListSection: View {
    let txns: [Transaction]
    let onEdit: (Transaction) -> Void
    let onDuplicate: (Transaction) -> Void
    let onDelete: (Transaction) -> Void

    // Group by start-of-day and sort sections newest → oldest
    private var grouped: [(day: Date, items: [Transaction])] {
        let groups = Dictionary(grouping: txns) { $0.date.startOfDay }
        return groups
            .map { (key: $0.key, value: $0.value.sorted { $0.date > $1.date }) }
            .sorted { $0.key > $1.key }
            .map { ($0.key, $0.value) }
    }

    var body: some View {
        List {
            ForEach(grouped, id: \.day) { day, items in
                Section {
                    ForEach(items, id: \.persistentModelID) { t in
                        TransactionRow(t: t)
                            .contentShape(Rectangle())
                            .onTapGesture { onEdit(t) }
                            .contextMenu {
                                Button(action: { onDuplicate(t) }) {
                                    Label("Duplicate", systemImage: "plus.square.on.square")
                                }
                                Button(action: { onEdit(t) }) {
                                    Label("Edit", systemImage: "pencil")
                                }
                                Button(role: .destructive, action: { onDelete(t) }) {
                                    Label("Delete", systemImage: "trash")
                                }
                            }
                            .swipeActions(edge: .leading, allowsFullSwipe: false) {
                                Button(action: { onEdit(t) }) {
                                    Label("Edit", systemImage: "pencil")
                                }
                                .tint(.blue)
                            }
                            .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                                Button(role: .destructive, action: { onDelete(t) }) {
                                    Label("Delete", systemImage: "trash")
                                }
                                Button(action: { onDuplicate(t) }) {
                                    Label("Duplicate", systemImage: "plus.square.on.square")
                                }
                                .tint(.teal)
                            }
                    }
                } header: {
                    HStack {
                        Text(Self.headerTitle(for: day))
                            .font(.subheadline)
                            .foregroundColor(.primary)
                    }
                    .textCase(nil)
                }
            }
        }
        .listStyle(.insetGrouped)
    }

    private static func headerTitle(for day: Date) -> String {
        if Calendar.current.isDateInToday(day) { return "Today" }
        if Calendar.current.isDateInYesterday(day) { return "Yesterday" }
        return DateFormatter.dayHeader.string(from: day)
    }
}

// MARK: - Helpers

private extension Date {
    var startOfDay: Date { Calendar.current.startOfDay(for: self) }
}

private extension DateFormatter {
    static let dayHeader: DateFormatter = {
        let df = DateFormatter()
        df.dateStyle = .full
        df.timeStyle = .none
        return df
    }()
}

private struct TotalPillOverlay: View {
    let title: String
    let amount: Double

    private var amountColor: Color {
        if amount > 0 { return .green }
        if amount < 0 { return .red }
        return .secondary
    }

    var body: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.caption).foregroundStyle(.primary)
                Text(amount.currency).font(.headline).foregroundStyle(amountColor)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
        }
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .padding(.leading, 24)
        .padding(.bottom, 24)
    }
}

private struct FabOverlay: View {
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            Image(systemName: "plus")
                .font(.system(size: 28, weight: .semibold))
                .foregroundStyle(.primary)
                .padding(20)
                .background(.ultraThinMaterial)
                .clipShape(Circle())
                .overlay(
                    Circle().stroke(Color.secondary.opacity(0.2), lineWidth: 1)
                )
                .shadow(radius: 4)
        }
        .padding(.trailing, 24)
        .padding(.bottom, 24)
    }
}

private struct QuickPickFlyoutOverlay: View {
    let isPresented: Bool
    let categories: [Category]
    let onDismiss: () -> Void
    let onPick: (Category) -> Void

    var body: some View {
        Group {
            if isPresented {
                ZStack(alignment: .bottomTrailing) {
                    Color.black.opacity(0.0001)
                        .ignoresSafeArea()
                        .onTapGesture { onDismiss() }

                    CategoryQuickPickFlyout(categories: categories, onPick: onPick)
                        .padding(.trailing, cardEdgeInset)
                        .padding(.bottom, flyoutBottomOffset)
                        .offset(y: -12)
                        .transition(.move(edge: .trailing).combined(with: .opacity))
                        .animation(.easeOut(duration: 0.18), value: isPresented)
                }
            }
        }
    }
}

private struct HeaderArea: View {
    @Binding var month: Date
    let spent: Double
    let budget: Double

    var body: some View {
        VStack(spacing: 8) {
            MonthHeader(month: $month)
            BudgetSummaryCard(spent: spent, budget: budget)
                .padding(.horizontal, 16)
        }
    }
}
