import SwiftUI

@main
struct SpenderPlusApp: App {
    var body: some Scene {
        WindowGroup {
            StandardScreen {
                ContentView()
            }
        }
    }
}
