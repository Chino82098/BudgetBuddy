import SwiftUI

struct TransactionRow: View {
    let t: Transaction

    // Precompute small pieces to keep the body simple (avoids type-checker crashes)
    private var iconName: String { t.category?.icon ?? "tray" }
    private var categoryName: String { t.category?.name ?? "Uncategorized" }

    private var tintBase: Color {
        // If you have Color(hex:) in your project, this will use it.
        // Otherwise falls back to a neutral gray.
        if let hex = t.category?.colorHex, let c = Color(hex: hex) {
            return c
        }
        return .gray
    }

    // Use a plain Color to avoid AnyShapeStyle + foregroundStyle complexity
    private var amountColor: Color {
        if t.amount == 0 { return .secondary }
        return t.amount < 0 ? .red : .green
    }

    // Avoid heavy chained formatting to help the type-checker
    private var formattedAmount: String {
        let nf = NumberFormatter()
        nf.numberStyle = .currency
        return nf.string(from: NSNumber(value: t.amount)) ?? String(format: "%.2f", t.amount)
    }

    var body: some View {
        HStack(spacing: 12) {
            GlassIcon(tint: tintBase, iconName: iconName)

            // Texts
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text(categoryName)
                        .font(.headline)

                    if t.isRecurring {
                        Image(systemName: "arrow.triangle.2.circlepath")
                            .imageScale(.small)
                            .foregroundStyle(.secondary)
                            .accessibilityLabel("Recurring")
                    }
                }

                if !t.note.isEmpty {
                    Text(t.note)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            }

            Spacer()

            // Amount + date
            VStack(alignment: .trailing, spacing: 2) {
                Text(formattedAmount)
                    .font(.headline)
                    .monospacedDigit()
                    .foregroundColor(amountColor)

                Text(t.date, style: .date)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(accessibilitySummary)
        .padding(.vertical, 4)
    }

    // MARK: - Accessibility
    private var accessibilitySummary: String {
        let dateString = DateFormatter.localizedString(from: t.date, dateStyle: .medium, timeStyle: .none)
        return "\(categoryName), \(formattedAmount), \(dateString)"
    }
}

// MARK: - Small pieces to keep body lean
private struct GlassIcon: View {
    let tint: Color
    let iconName: String

    var body: some View {
        ZStack {
            glassBody

            // Very light category tint over the glass
            Circle().fill(tint.opacity(0.14))

            // Icon
            Image(systemName: iconName)
                .font(.system(size: 16, weight: .semibold))
                .symbolRenderingMode(.hierarchical)
                .foregroundStyle(.primary)
        }
        .frame(width: 36, height: 36)
        // Subtle highlight ring for glass edge
        .overlay(
            Circle()
                .stroke(Color.white.opacity(0.18), lineWidth: 0.5)
                .blendMode(.plusLighter)
        )
    }

    @ViewBuilder
    private var glassBody: some View {
        // Use the new Liquid Glass when available; otherwise a stable fallback.
        if #available(iOS 26, *) {
            Circle()
                .glassEffect(.clear.interactive(), in: .circle)
        } else {
            Circle()
                .fill(.ultraThinMaterial)
        }
    }
}
